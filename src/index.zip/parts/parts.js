// parts

import b_1 from "../assets/images/partnft/b/1.png";
import b_2 from "../assets/images/partnft/b/2.png";
import b_3 from "../assets/images/partnft/b/3.png";
import b_4 from "../assets/images/partnft/b/4.png";
import b_5 from "../assets/images/partnft/b/5.png";


import face from "../assets/images/partnft/Face/Face.png";


import e_1 from "../assets/images/partnft/Eyes/Eyes 1.png";
import e_2 from "../assets/images/partnft/Eyes/Eyes 2.png";
import e_3 from "../assets/images/partnft/Eyes/Eyes 3.png";
import e_4 from "../assets/images/partnft/Eyes/Eyes 4.png";
import e_5 from "../assets/images/partnft/Eyes/Eyes 5.png";


import h_1 from "../assets/images/partnft/Hair/Hair 1.png";
import h_2 from "../assets/images/partnft/Hair/Hair 2.png";
import h_3 from "../assets/images/partnft/Hair/Hair 3.png";
import h_4 from "../assets/images/partnft/Hair/Hair 4.png";
import h_5 from "../assets/images/partnft/Hair/Hair 5.png";



import g_1 from "../assets/images/partnft/Specs/Shades 1.png";
import g_2 from "../assets/images/partnft/Specs/Shades 2.png";
import g_3 from "../assets/images/partnft/Specs/Shades 3.png";
import g_4 from "../assets/images/partnft/Specs/Shades 4.png";
import g_5 from "../assets/images/partnft/Specs/Shades 5.png";

import g_6 from "../assets/images/partnft/Sp/Sp 1.png";
import g_7 from "../assets/images/partnft/Sp/Sp 2.png";
import g_8 from "../assets/images/partnft/Sp/Sp 3.png";
import g_9 from "../assets/images/partnft/Sp/Sp 4.png";
import g_10 from "../assets/images/partnft/Sp/Sp 5.png";


import m_1 from "../assets/images/partnft/Mask/Mask 1.png";
import m_2 from "../assets/images/partnft/Mask/Mask 2.png";
import m_3 from "../assets/images/partnft/Mask/Mask 3.png";
import m_4 from "../assets/images/partnft/Mask/Mask 4.png";
import m_5 from "../assets/images/partnft/Mask/Mask 5.png";
import m_6 from "../assets/images/partnft/Mask/Mask 6.png";
import m_7 from "../assets/images/partnft/Mask/Mask 7.png";
import m_8 from "../assets/images/partnft/Mask/Mask 8.png";
import m_9 from "../assets/images/partnft/Mask/Mask 9.png";
import m_10 from "../assets/images/partnft/Mask/Mask 10.png";




export const parts = {
  bg: [b_1, b_2, b_3, b_4, b_5],
  face: [face],
  eyes: [e_1, e_2, e_3, e_4, e_5],
  hair: [h_1, h_2, h_3, h_4, h_5],
  glasses: [g_1, g_2, g_3, g_4, g_5, g_6, g_7, g_8, g_9, g_10],
  mask: [m_1, m_2, m_3, m_4, m_5, m_6, m_7, m_8, m_9, m_10],
  
};
